<?php
session_start();
require_once('config.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $student_id = $_POST['student_id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $dept = $_POST['dept'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone_no = $_POST['phone_no'];

 
    $sqlquery = "INSERT INTO student_reg (student_id, fname, lname, address, gender, dept, email, password, phone_no) 
                 VALUES ('$student_id', '$fname', '$lname', '$address', '$gender', '$dept', '$email', '$password', '$phone_no')";
    if (mysqli_query($conn, $sqlquery)) {
        echo "<script>alert('Added Successfully');
              window.location.href='login.php';
              </script>";
    } else {
        echo "<script>alert('Failed to add');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Register</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
      <style>
        
        .bg-gradient-primary {
            background-color: #ffffff; 
            background-image: linear-gradient(180deg, #3498db 0%, #000000 100%);

            background-size: cover;
        }
    </style>
</head>
<body class="bg-gradient-primary">
<div class="container">
    <div class="fancy-hero-area bg-img bg-overlay animated-img"></div>
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-5 d-none d-lg-block" style="background-image: url(logo.png); background-size: 440px ; background-position:top; background-repeat: no-repeat;" ></div>
                <div class="col-lg-7">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="h2 bold text-gray-900 mb-8">Welcome to SLSU</h1>
                            <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                        </div>
                        <form class="user" action="" method="POST">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" name="student_id" id="student_id" placeholder="Student ID" required>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text" name="fname" class="form-control form-control-user" id="fname" placeholder="First Name" required>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-user" name="lname" id="lname" placeholder="Last Name" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" name="address" id="address" placeholder="Address" required>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="gender" id="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" name="dept" id="dept" placeholder="Department" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control form-control-user" id="email" placeholder="Email Address" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control form-control-user" id="password" placeholder="Password" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" name="phone_no" id="phone_no" placeholder="Phone number">
                            </div>
                            <button type="submit" class="btn btn-primary btn-user btn-block">Register Account</button>
                            <a class="small" href="login.php"></a>
                            <hr>
                        </form>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>
</body>
</html>
