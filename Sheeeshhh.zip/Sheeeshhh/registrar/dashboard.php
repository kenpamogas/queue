<?php


require_once('../config.php');

function sanitize($data) {
    return htmlspecialchars(strip_tags($data));
}

if ($_SERVER['REQUEST_METHOD'] == "GET"){
    $student_idFilter = isset($_GET['student_id']) ? sanitize($_GET['student_id']) : '';
    
    $sqlquery = "SELECT * FROM registrar WHERE 1";

    if (!empty($student_idFilter)) {
        $sqlquery .= " AND student_id LIKE '%$Student_IDFilter%'";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['que_no']) && isset($_POST['student_id']) && isset($_POST['student_fullname'])) {

    $queue_number = intval($_POST['que_no']);
    if ($queue_number < 1001 || $queue_number > 1999) {
        die("Invalid queue number.");
    }
    
    $student_id = $_POST['student_id'];
    $student_fullname = $_POST['student_fullname'];
    

    $sql = "INSERT INTO registrar (queue_date, queue_number, student_id, student_fullname) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    $queue_date = date("Y-m-d");
    
    $stmt->bind_param("siss", $queue_date, $queue_number, $student_id, $student_fullname);
    
    if ($stmt->execute()) {
        echo "Record inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $stmt->close();
}
?>

<!DOCTYPE html>

<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/..assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="../vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>

        <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            box-sizing: border-box;
        }
        h1, h2 {
            color: #333;
            text-align: center;
        }
        button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
            outline: none;
        }
        button:hover {
            background-color: #45a049;
        }
        #queueNumber {
            font-size: 32px;
            font-weight: bold;
            padding: 20px;
            border: 3px solid #4CAF50;
            border-radius: 50%;
            margin: 0 10px;
            width: 120px;
            height: 120px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            color: #4CAF50;
            box-sizing: border-box;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
    </style>
    <script src="../https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
        function fetchNextQueueNumber() {
            var currentDate = new Date().toISOString().slice(0, 10);

            $.ajax({
                url: 'que_number.php',
                type: 'GET',
                success: function(response) {
                    var responseData = JSON.parse(response);
                    var nextQueueNumber = responseData.queueNumber;
                    var queueDate = responseData.queueDate;

                    if (currentDate !== queueDate) {
                        nextQueueNumber = 1001;
                    }

                    document.getElementById('queueNumber').innerText = nextQueueNumber;

                    updateOnServeQueueNumber(nextQueueNumber);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }

        function updateOnServeQueueNumber(queueNumber) {
            $.ajax({
                url: 'update_queuing_number.php',
                type: 'POST',
                data: { queueNumber: queueNumber },
                success: function(response) {
                    console.log('On-serve queue number updated successfully.');
                },
                error: function(xhr, status, error) {
                    console.error('Failed to update on-serve queue number:', xhr.responseText);
                }
            });
        }

        function incrementQueueNumber() {
            var currentNumber = parseInt(document.getElementById('queueNumber').innerText);
            if (currentNumber >= 3999) {
                document.getElementById('queueNumber').innerText = 3001;
            } else {
                document.getElementById('queueNumber').innerText = currentNumber + 1;
            }
        }

        function decrementQueueNumber() {
            var currentNumber = parseInt(document.getElementById('queueNumber').innerText);
            if (currentNumber <= 3001) {
                document.getElementById('queueNumber').innerText = 2999;
            } else {
                document.getElementById('queueNumber').innerText = currentNumber - 1;
            }
        }

        function confirmServed() {
            var que_no = document.getElementById('queueNumber').innerText;
            $.ajax({
                url: 'served.php',
                type: 'POST',
                data: { que_no: que_no },
                success: function(response) {
                    document.getElementById('queueNumber').innerText = response;
                    fetchServedQueueNumbers();
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }
        
        function fetchServedQueueNumbers() {
            $.ajax({
                url: 'on_served_queuing_number.php',
                type: 'GET',
                success: function(response) {
                    $('#servedQueueList').html(response);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }

        $(document).ready(function() {
            fetchNextQueueNumber();
            fetchServedQueueNumbers();
        });
    </script>


  </head>

  <body>


       

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">



              <!-- Search -->
              <center> 
                <p class="align-items-center ms-auto" style="font-size: 18px; padding-right: 500px; padding-top: 15px;"><b>International State College of the Philippines</b></p>  
              </center>



              <!-- /Search -->

                  <ul class="dropdown-menu dropdown-menu-end">
                    
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- Content wrapper -->
          <div class="content-wrapper">


            <!-- Content -->

            <!-- registrar -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-7">
                        <div class="card-body">
                          
                          <div class="container">
 
                            <button onclick="decrementQueueNumber()">Previous</button>
                            <span id="queueNumber">3001</span>
                            <button onclick="incrementQueueNumber()">Next</button>
                            <center>
                                <button style="margin-right: 90px;" onclick="confirmServed()">Finish Serving</button>
                            </center>

                            <table border="1">
                                <thead>
                                    <tr>
                                        <th>Queue Number</th>
                                        <th>Student ID</th>
                                        <th>Student Fullname</th>
                                    </tr>
                                </thead>
                                <tbody id="servedQueueList">
                                </tbody>
                                <?php
                                    $sql = "SELECT * FROM cashier WHERE IsActive = 1";
                                    
                                        
                                    if($result = mysqli_query($conn, $sql)){
                                        while($row = mysqli_fetch_array($result)){
                                            echo"<tr>";
                                            echo "<th>" . $row['Que_no'] . "</th>";
                                            echo "<th>" . $row['Student_ID'] . "</th>";
                                            echo "<th>" . $row['student_fullname'] . "</th>";
                                            echo "</tr>";
                                        }
                                    }
                                ?>
                            </table>
                        </div>

                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="../assets/img/illustrations/man-with-laptop-light.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  , made with ❤️ by
                  <a href="https://themeselection.com" target="_blank" class="footer-link fw-bolder">ThemeSelection</a>
                </div>

              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>