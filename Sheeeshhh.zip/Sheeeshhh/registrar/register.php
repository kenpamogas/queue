<?php
include '../config.php';

function getNextQueueNumber($conn) {
    $currentDate = date("Y-m-d");
    
    // Check if there are existing queue numbers for the current date
    $result = $conn->query("SELECT MAX(que_no) AS max_que FROM registrar WHERE date = '$currentDate'");
    $row = $result->fetch_assoc();
    
    // If there are no queue numbers yet, return 1001
    if ($result->num_rows === 0 || $row['max_que'] === null) {
        return 1001;
    }
    
    // Otherwise, increment the max queue number by 1
    return intval($row['max_que']) + 1;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = substr($_POST['student_id'] ?? '', 0, 20); 
    $student_fullname = substr($_POST['student_fullname'] ?? '', 0, 100); 

    // Check if student is registered
    $stmt = $conn->prepare("SELECT * FROM student_reg WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        $message = "Student with ID $student_id is not registered yet.";
    } else {
        // Check time since last registration
        $stmt = $conn->prepare("SELECT MAX(date) AS last_registration FROM registrar WHERE student_id = ?");
        $stmt->bind_param("s", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $last_registration = isset($row['last_registration']) ? strtotime($row['last_registration']) : 0;
        $current_time = time();
        if ($current_time - $last_registration < 120) {
            $message = "You cannot register again so soon. Please wait for 2 minutes.";
        } else {
            // Get next queue number
            $que_no = getNextQueueNumber($conn);
            $currentDate = date("Y-m-d");

            // Insert record into registrar table
            $stmt = $conn->prepare("INSERT INTO registrar (date, que_no, student_id, student_fullname, IsActive) VALUES (?, ?, ?, ?, 1)");
            $stmt->bind_param("siss", $currentDate, $que_no, $student_id, $student_fullname);

            if ($stmt->execute()) {
                $message = "Priority number reserved successfully. Your queue number is: $que_no";
            } else {
                $message = "Error: " . $stmt->error;
            }

            $stmt->close();
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>A D M I N - REGISTRAR</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="../https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
     <style>
     
        .bg-gradient-primary {
            background-color: #ffffff; /* fallback for old browsers */
            background-image: linear-gradient(180deg, #3498db 0%, #000000 100%);

            background-size: cover;
        }
    </style>

</head>
<body>
    <body class="bg-gradient-primary">
     
    <div class="container">
         <div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(bg.jpg);"></div>
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block" style="background-image: url(../logo.png); background-size: 320px ; background-position:center; background-repeat: no-repeat;" ></div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h2 bold text-gray-900 mb-8">Welcome to SLSU</h1>
                                <h1 class="h4 text-gray-900 mb-4">Add priority number!</h1>
                            </div>
                        <form class="user" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                             <?php if(isset($message)): ?>
                              <p><?php echo $message; ?></p>
                                    <?php endif; ?>
                                <div class="form-group">
                                        <input type="text" class="form-control form-control-user" name="student_id" id="student_id"
                                            placeholder="Student ID"required>
                                        </div>                                 
                                <div class="form-group">
                                        <input type="text" name="student_fullname" class="form-control form-control-user" id="student_fullname"
                                            placeholder="First Name"required>
                                    </div>
                                <button type="submit" class="btn btn-danger btn-user btn-block">
                                    Add Priority Number
                                </button>
                               
                            </form>
            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>
</body>
</html>
