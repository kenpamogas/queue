-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 31, 2024 at 04:08 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `queuing11`
--

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `date` date NOT NULL,
  `que_no` int UNSIGNED NOT NULL,
  `student_id` varchar(255) DEFAULT NULL,
  `student_fullname` varchar(50) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`date`, `que_no`, `student_id`, `student_fullname`, `IsActive`) VALUES
('2024-03-30', 3001, '2210189-1', '', 1),
('2024-03-30', 3002, '2210189-1', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `registrar`
--

CREATE TABLE `registrar` (
  `date` date NOT NULL,
  `que_no` int UNSIGNED NOT NULL,
  `student_id` varchar(255) DEFAULT NULL,
  `student_fullname` varchar(50) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `registrar`
--

INSERT INTO `registrar` (`date`, `que_no`, `student_id`, `student_fullname`, `IsActive`) VALUES
('2024-03-30', 1001, '2210189-1', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sas`
--

CREATE TABLE `sas` (
  `date` date NOT NULL,
  `que_no` int UNSIGNED NOT NULL,
  `student_id` varchar(255) DEFAULT NULL,
  `student_fullname` varchar(50) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sas`
--

INSERT INTO `sas` (`date`, `que_no`, `student_id`, `student_fullname`, `IsActive`) VALUES
('2024-03-30', 2001, '2210189-1', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_reg`
--

CREATE TABLE `student_reg` (
  `student_id` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dept` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student_reg`
--

INSERT INTO `student_reg` (`student_id`, `fname`, `lname`, `address`, `gender`, `dept`, `email`, `password`, `phone_no`) VALUES
('2210189-1', 'jamail', 'mangutara', 'San antonio Malitbog Southern Leyte', 'male', 'BSIT', 'jamailmangotara69@gmail.com', '123', '09639152962');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`date`,`que_no`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `registrar`
--
ALTER TABLE `registrar`
  ADD PRIMARY KEY (`date`,`que_no`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `sas`
--
ALTER TABLE `sas`
  ADD PRIMARY KEY (`date`,`que_no`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `student_reg`
--
ALTER TABLE `student_reg`
  ADD PRIMARY KEY (`student_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cashier`
--
ALTER TABLE `cashier`
  ADD CONSTRAINT `cashier_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_reg` (`student_id`);

--
-- Constraints for table `registrar`
--
ALTER TABLE `registrar`
  ADD CONSTRAINT `registrar_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_reg` (`student_id`);

--
-- Constraints for table `sas`
--
ALTER TABLE `sas`
  ADD CONSTRAINT `sas_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_reg` (`student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
